import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-deleteuser',
  templateUrl: './deleteuser.component.html',
  styleUrls: ['./deleteuser.component.css']
})
export class DeleteuserComponent implements OnInit {
  
  userId:number = 0;
  msg:String;
  errorMsg:String;

  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }
  
  deleteuser(){
    console.log(this.userId);
    
    this.userService.deleteuser(this.userId).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.userId=null;},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }

}
