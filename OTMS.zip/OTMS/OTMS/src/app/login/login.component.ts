import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Routes, RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userId:number = 0;
  password:string=" ";
  msg:String;
  errorMsg:String;

  constructor(private userService:UserService,private router: Router) { }

  ngOnInit(): void {
  }
login(){
  console.log(this.userId,this.password);
  
  this.userService.login(this.userId,this.password).subscribe(response => 
    this.hello(response));
}
hello(response)
{
  this.msg=response;
  if (this.msg=="Admin") {
    this.errorMsg="Welcome Admin";
    this.router.navigate(['/adminview']);
  } 
  else if (this.msg=="Student") {
    this.errorMsg="Welcome Student";
    this.router.navigate(['/studentview']);
} 
else if (this.msg=="Wrong Password") {
  this.errorMsg=" Check your credentials ";
  this.router.navigate(['/login']);
  
} 
else {
  this.errorMsg=" Register First ";
  this.router.navigate(['/register']);
  
}
}
}
