import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user:User=new User();
  msg:String;
  errorMsg:String;
  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }
  register(){
    console.log("inside register"+this.user.userName);
    this.userService.register(this.user).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.user=new User()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }

}


