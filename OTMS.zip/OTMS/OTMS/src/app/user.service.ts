import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  public viewalluser():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:7070/viewalluser");
  }

 public register(user:User):Observable<any>{
  console.log("Am inside service"+user.userName);
    return this.http.post("http://localhost:7070/Register",user,{responseType:'text'});
  }

  public login(userId:number,password:string):Observable<any>{
    return this.http.post("http://localhost:7070/login/"+userId,password,{responseType:'text'});
  }

  deleteuser(userId: number):Observable<any> {
    console.log("inside delete service "+userId);
    return this.http.delete("http://localhost:7070/deleteuser/"+userId,{responseType:'text'});
  }

  logout():Observable<any> {
    console.log("inside  service delete");
    return this.http.get("http://localhost:7070/user/logout/");
  }


}
