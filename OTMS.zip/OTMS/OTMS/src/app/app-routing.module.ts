import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { DeleteuserComponent } from './deleteuser/deleteuser.component';
import{ ViewalluserComponent } from './viewalluser/viewalluser.component';
import{ LoginComponent } from './login/login.component';
import{ LogoutComponent } from './logout/logout.component';
import{ AdminviewComponent } from './adminview/adminview.component';
import{ StudentviewComponent } from './studentview/studentview.component';





const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch: 'full'},
  {path: 'home',component:HomeComponent},
  {path:'register', component:RegisterComponent},
  {path:'deleteuser', component:DeleteuserComponent},
  {path:'viewalluser', component:ViewalluserComponent},
  {path:'login', component:LoginComponent},
  {path:'logout', component:LogoutComponent},
  {path:'adminview', component:AdminviewComponent},
  {path:'studentview', component:StudentviewComponent},

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
