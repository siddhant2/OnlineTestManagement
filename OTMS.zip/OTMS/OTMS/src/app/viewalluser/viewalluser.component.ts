import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';


@Component({
  selector: 'app-viewalluser',
  templateUrl: './viewalluser.component.html',
  styleUrls: ['./viewalluser.component.css']
})
export class ViewalluserComponent implements OnInit {
  
  user:User[]=[];
  
  constructor(private userService:UserService) { }

  ngOnInit(): void {
    console.log("Am inside view component");
    this.userService.viewalluser().subscribe(data=>this.user=data);
    console.log(this.user);
  }

}
