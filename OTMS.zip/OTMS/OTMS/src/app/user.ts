export class User {
    userId:number;
    userName:String;
    password:String;
    isAdmin:boolean;
}
